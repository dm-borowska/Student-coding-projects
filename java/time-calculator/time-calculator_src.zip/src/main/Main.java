package main;

import zegary.Czas;

public class Main {
    public Czas koniecZajęć(Czas start, int[] przerwy) {

        Czas lekcja = new Czas(0, 45, 0);
        int ileLekcji = przerwy.length + 1;
        lekcja = lekcja.pomnóż(ileLekcji); // tyle będą trwały zajęcia

        int sumaPrzerw = 0;
        for (int i = 0; i < ileLekcji - 1; i++) { // dowiaduję się ile trwają przerwy
            sumaPrzerw += przerwy[i];
        }
        Czas czasPrzerw = new Czas(0);
        if (sumaPrzerw < 60) {
            czasPrzerw = new Czas(0, sumaPrzerw, 0); // tyle wynosi czas przerw
        } else { // przerwy trwają ponad godzinę
            int godzina = sumaPrzerw / 60;
            int minuta = sumaPrzerw % 60;
            czasPrzerw = new Czas(godzina, minuta, 0);
        }

        Czas koniec_zajęć = start.dodaj(lekcja);
        koniec_zajęć = koniec_zajęć.dodaj(czasPrzerw);

        return koniec_zajęć;
    }

    public void testy() {
        // tworzę czasy do testów, tworzę zmienne, wywołuję metody
        Czas czas = new Czas();
        Czas teraz = new Czas();
        Czas czas1 = new Czas(3, 2, 1);
        Czas czas2 = new Czas(4, 5, 6);
        Czas dodawanie = czas1.dodaj(czas2);
        int czynnik2 = 2;
        Czas pomnóż = czas1.pomnóż(czynnik2);
        Czas zGodziny = Czas.zGodziny(3);
        Czas zMinut = Czas.zMinut(2);
        Czas zSekund = Czas.zSekund(1);
        Czas czasToString2 = new Czas(0, 0, 0);
        Czas granicznyDodaj = new Czas(23, 59, 59).dodaj(new Czas(0, 0, 1));
        Czas granicznyPomnóż = new Czas(0, 59, 59).pomnóż(2);

        //wywołuję i sprawdzam asercjami
        assert czas.godzina() == teraz.godzina() && czas.minuta() == teraz.minuta()
                && czas.sekunda() == teraz.sekunda() : "Źle działa LocalTime!";
        assert czas1.godzina() == 3 && czas1.minuta() == 2 && czas1.sekunda() == 1 : "Błąd! Czas to: 03:02:01";

        assert czas1.równa(czas1) : (czas1 + " powinien być równy" + czas1);
        assert !czas1.równa(czas2) : (czas1 + " =/= " + czas2);

        assert czas1.przed(czas2) : (czas1 + "powinien być przed " + czas2);

        assert dodawanie.godzina() == 7 : "Godzina powinna wynosić 7";
        assert dodawanie.minuta() == 7 : "Minuta powinna wynosić 7";
        assert dodawanie.sekunda() == 7 : "Sekunda powinna wynosić 7";
        assert granicznyDodaj.toString().equals("00:00:00") : "Błąd w zawijaniu czasu dla dodawania!";

        assert pomnóż.godzina() == 6 : "Godzina powinna wynosić 6";
        assert pomnóż.minuta() == 4 : "Minuta powinna wynosić 4";
        assert pomnóż.sekunda() == 2 : "Sekunda powinna wynosić 2";
        assert granicznyPomnóż.toString().equals("01:59:58") : "Błąd w zawijaniu czasu dla mnożenia!";

        assert czasToString2.toString().equals("00:00:00") : "Błąd w toString! Oczekiwano 00:00:00, otrzymano: " + czasToString2;

        // sprawdzam metody klasowe
        assert zGodziny.godzina() == 3 : "Godzina powinna równać się 3";
        assert zMinut.minuta() == 2 : "Minuta powinna równać się 2";
        assert zSekund.sekunda() == 1 : "Sekunda powinna równać się 1";
    }

    public static void main(String[] args) {

        // To powinno paść, jeśli tak się stanie, należy wykomentować poniższą linię.
        //Czas zły = new Czas(25, 128, -1); Asercja włączona poprawnie

        Main main = new Main();
        main.testy();

        System.out.println("Witaj szkoło!");
        int[] przerwy = {5, 10, 5, 10, 25, 10, 5};
        Czas początek = new Czas(8, 15, 0);
        System.out.println("Zaczynamy o: " + początek);

        Czas koniec = main.koniecZajęć(początek, przerwy);

        System.out.println("Kończymy: " + koniec);
        System.out.println("Jest już ciemno ...");
    }
}