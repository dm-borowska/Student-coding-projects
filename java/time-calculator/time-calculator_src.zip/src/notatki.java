//public class notatki {
//
//    Klasa obiekt = new Klasa(); // Tworzenie obiektu klasy
//    NazwaKlasy nazwaObiektu = new NazwaKlasy();
//
//    // this odnosi się do bieżącego obiektu klasy. Używane, gdy chcemy odróżnić zmienne lokalne od atrybutów klasy lub przekazać bieżący obiekt.
//    public void ustawGodzina(int godzina) {
//        this.godzina = godzina; // "this.godzina" odnosi się do atrybutu klasy
//    }
//
//    //static - metoda lub zmienna należy do klasy, a nie do konkretnego obiektu.
//    public static int licznik = 0;
//
//    assert (warunek) : "Komunikat błędu";
//
//    // deklaracja pakietu
//    package nazwaPakietu;
//
//    //użycie pakietu w innej klasie
//    import zegary.Czas;
//
//
//    //KONSTRUKTOR
//
//    public Czas() {
//        this.godzina = 0;
//        this.minuta = 0;
//        this.sekunda = 0;
//    }
//
//    public Czas(int godzina, int minuta, int sekunda) {
//        this.godzina = godzina;
//        this.minuta = minuta;
//        this.sekunda = sekunda;
//    }
//
//    // inne metody
//    public [typ_zwracany] nazwaMetody([parametry]) {
//        // ciało metody
//    }
//
//    // Geter służy do odczytu wartości prywatnych atrybutów klasy.
//    public int getGodzina() {
//        return godzina;
//    }
//
//    // Seter służy do zmiany wartości prywatnych atrybutów klasy.
//    public void setGodzina(int godzina) {
//        this.godzina = godzina;
//    }
//
//
//
//
//}
