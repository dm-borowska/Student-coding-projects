package zegary;

import java.time.LocalTime;

public class Czas {

    // ATRYBUTY

    private int godzina;
    private int minuta;
    private int sekunda;

    // KONSTRUKTORY

    public Czas() { // BEZPARAMETROWY konstruktor; powinien być publiczny
        LocalTime teraz = LocalTime.now();

        this.godzina = teraz.getHour();
        this.minuta = teraz.getMinute();
        this.sekunda = teraz.getSecond();
    }

    public Czas(int godzina) { // pełna godzina
        this.godzina = godzina;
        this.minuta = 0;
        this.sekunda = 0;
        assert (godzina >= 0 && godzina <= 23) : "Godzina musi być nieujemna i nie większa niż 23!";
    }

    public Czas(int godzina, int minuta) { // zadana godzina i minuta, 0 sekund
        this.godzina = godzina;
        this.minuta = minuta;
        this.sekunda = 0;
        assert (godzina >= 0 && godzina <= 23) : "Godzina musi być nieujemna i nie większa niż 23!";
        assert (minuta >= 0 && minuta <= 59) : "Minuta musi być nieujemna i nie większa niż 60!";
    }

    public Czas(int godzina, int minuta, int sekunda) { // zadana godzina, minuta i sekunda
        this.godzina = godzina;
        this.minuta = minuta;
        this.sekunda = sekunda;
        assert (godzina >= 0 && godzina <= 23) : "Godzina musi być nieujemna i nie większa niż 23!";
        assert (minuta >= 0 && minuta < 60) : "Minuta musi być nieujemna i nie większa niż 60!";
        assert (sekunda >= 0 && sekunda < 60) : "Sekunda musi być nieujemna i nie większa niż 60!";
    }

    // METODY

    // GETERY

    public int godzina() { // geter godziny konwencja z wykładu!
        return godzina;
    }

    public int minuta() { // geter minuty
        return minuta;
    }

    public int sekunda() { // geter sekundy
        return sekunda;
    }

    // METODY KLASOWE

    public static Czas zGodziny(int godzina) {
        return new Czas(godzina, 0, 0);
    }

    public static Czas zMinut(int minuta) {
        return new Czas(0, minuta, 0);
    }

    public static Czas zSekund(int sekunda) {
        return new Czas(0, 0, sekunda);
    }

    // INNE METODY

    public boolean równa(Czas zadany) { // tylko w przypadku, gdy równe są
        // godziny i minuty i sekundy czas jest równy
        return (this.godzina() == zadany.godzina() &&
                this.minuta() == zadany.minuta() &&
                this.sekunda() == zadany.sekunda());
    }

    public boolean przed(Czas zadany) {
        if (zadany.godzina() > this.godzina()) { //zaczynamy od porównania godzin
            return true;
        } else if (zadany.godzina() < this.godzina()) {
            return false;
        }

        // godziny są równe, więc trzeba sprawdzić minuty
        if (zadany.minuta() > this.minuta()) { // więc zaczynamy sprawdzenie od minut
            return true;
        } else if (zadany.minuta() < this.minuta()) {
            return false;
        }

        //minuty są równe więc trzeba sprawdzić sekundy
        return (zadany.sekunda() > this.sekunda());
    }

    public Czas dodaj(Czas składnik) { // tworzy nowy obiekt jako sumę
        int godz = 0; // zmienne, w których zapamiętuję ostateczne wyniki
        int min = 0;
        int sek = 0;

        // pobieram wartości godzin, minut i sekund
        int godzinaSkładnika = składnik.godzina();
        int minutaSkładnika = składnik.minuta();
        int sekundaSkładnika = składnik.sekunda();

        if (this.sekunda + sekundaSkładnika + sek < 60)
            sek += this.sekunda + sekundaSkładnika; // poniżej 60 sek jest ok
        else {
            min += (this.sekunda + sekundaSkładnika) / 60; // przekroczyło zakres sekund,
            // więc trzeba zwiększyć minuty
            sek = (this.sekunda + sekundaSkładnika + sek) % 60; // nowe sekundy to
            // reszta z dzielenia
        }

        if (this.minuta + minutaSkładnika + min < 60) min += this.minuta + minutaSkładnika; // poniżej 60 sek jest ok
        else { // analogicznie
            godz += ((this.minuta + minutaSkładnika + min) / 60);
            min = ((this.minuta + minutaSkładnika + min) % 60); // samo = (a nie +=), bo nie chcemy
            // podwójnie przypisywać min i przekraczać 59 sekund
        }

        if (this.godzina + godzinaSkładnika + godz <= 23)
            godz += this.godzina + godzinaSkładnika; // jeśli wyrobimy się w 1 dobie to jest ok
        else {
            godz = (this.godzina + godzinaSkładnika + godz) % 24; // zawijanie doby
        }

        return new Czas(godz, min, sek); // zwróci nowy obiekt klasy czas (wynik dodawania)
    }

    public Czas pomnóż(int czynnik) { // tworzy nowy obiekt jako wynik mnożenia
        assert (czynnik > 0) : "Czynnik mnożenia musi być dodatni!";

        // mnożę składniki czasu przez czynnik
        int sekunda = this.sekunda * czynnik;
        int minuta = this.minuta * czynnik;
        int godzina = this.godzina * czynnik;

        // poprawiam czas tak, by jego wartości były w odpowiednich zakresach
        // (zawijanie analogiczne jak w metodzie dodaj)
        // jeśli wszystjo jest ok to po prostu zwracam zmienne godzina, minuta, sekunda
        if (sekunda >= 60) {
            minuta += sekunda / 60;
            sekunda = sekunda % 60;
        }

        if (minuta >= 60) {
            godzina += minuta / 60;
            minuta = minuta % 60;
        }

        if (godzina >= 24) {
            godzina = godzina % 24;
        }

        return new Czas(godzina, minuta, sekunda); // zwraca nowy obiekt, wynik mnożenia
    }

    @Override // nadpisuję, gdyż domyślne toString działa inaczej
    public String toString() {
        return String.format("%02d:%02d:%02d", godzina, minuta, sekunda); // ustalam formatowanie
    }
}